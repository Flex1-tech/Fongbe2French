# Projet fongbé -> français : socle commun + P0 (Wadoud)

## Ce qu'il y a dans ce dossier
| Dossier / fichier | À quoi ça sert |
|---|---|
| `data/train.csv`, `val.csv`, `test.csv` | Les données de l'équipe (27 730 / 2 242 / 1 856 paires). **Ne pas modifier.** |
| `tokenizers/fr.model` | Tokenizer français de l'équipe (vocabulaire 4 000). **Ne pas modifier.** |
| `tokenizers/fon.model` | Tokenizer fongbé (vocabulaire 2 000), créé à partir du train. |
| `config.yaml` | Tous les réglages communs (taille du modèle, vitesse d'apprentissage, etc.). |
| `scripts/models.py` | Les 3 modèles : A2, A3, A6. |
| `scripts/train.py` | Lance un entraînement. |
| `scripts/evaluate.py` | Calcule les scores BLEU et chrF. |
| `scripts/train_fon_tokenizer.py` | A servi à fabriquer `fon.model` (inutile de le relancer). |
| `data/checksums.json` | Empreintes des fichiers : tout le monde doit avoir les mêmes. |

## Lancer P0 sur Google Colab (pas à pas)
1. Va sur colab.research.google.com, crée un nouveau notebook.
2. Menu **Exécution > Modifier le type d'exécution > GPU (T4)**, puis Enregistrer.
3. Dans le panneau de gauche (icône dossier), envoie `fonfr_P0.zip` (glisser-déposer).
4. Dans une cellule, colle et exécute (flèche ▶) :
```
!unzip -q fonfr_P0.zip
%cd fonfr2
!pip install -q sentencepiece sacrebleu pyyaml
```
5. Dans une nouvelle cellule, **monte Google Drive** pour ne rien perdre si Colab se déconnecte :
```
from google.colab import drive
drive.mount('/content/drive')
```
6. Lance l'entraînement (A2 d'abord) :
```
!python scripts/train.py --pipeline P0 --arch a2 --seed 1 --run_dir /content/drive/MyDrive/fonfr_runs/P0_a2_s1
```
7. Si Colab se coupe, relance la même commande en ajoutant `--resume` à la fin : il repart où il s'était arrêté.
8. À la fin, ouvre `results.json` dans le dossier d'exécution. Ensuite A3 et A6 : remplace `a2` par `a3` puis `a6` (dans `--arch` et dans `--run_dir`).

## Ce que tu vois pendant l'entraînement
Une ligne toutes les 1 000 mises à jour, par exemple : `mise à jour 1000 | epoch 1 | train 4.2 | val 4.5 | chrF 12.3 | 8.0 min *meilleur*`
- **train** et **val** : l'erreur du modèle. Elle doit **baisser**.
- **\*meilleur\*** : le modèle vient de battre son record sur la validation, il est sauvegardé.
- **patience 2/3** : pas de progrès depuis 2 contrôles ; à 3/3 l'entraînement s'arrête tout seul.
- **chrF** : note de qualité de traduction (0 à 100), plus haut = mieux.

## Le calibrage de P0 (étape importante)
Après le premier entraînement (A2), `results.json` contient :
- `secondes_par_epoch` : le temps d'un tour complet des données ;
- `minutes_pour_meilleur_point` : le temps qu'il a fallu pour atteindre son meilleur état ;
- `plafond_temps_propose_min` : ce temps x 1,5, à donner comme plafond à toute l'équipe ;
- `conseil_epochs` : dit s'il faut passer de 30 à 50 epochs.
Mets le plafond dans `config.yaml` (ligne `time_cap_minutes`) et envoie le fichier à l'équipe **avant** qu'ils lancent leurs pipelines.

## Autres commandes utiles
- Comparer deux modèles : `python scripts/evaluate.py --hyp A/val_hyp.txt --ref A/val_ref.txt --baseline B/val_hyp.txt`
- Test final (UNE seule fois, modèle final) : ajouter `--eval_test` à la commande d'entraînement.

## Points d'attention (à écrire dans le rapport)
- Environ 5 % des phrases de val et de test ont une **traduction française identique** à une phrase du train (114 en val, 95 en test, avec un texte fongbé différent). Ce sont surtout des phrases courtes et banales. Cela peut gonfler un peu les scores, sans faire de grosse différence.
- Le même texte fongbé n'apparaît jamais à la fois dans le train et dans val/test (vérifié).
- Le tokenizer fongbé (2 000) est un choix : on peut le refaire avec `--vocab 3000` si l'équipe le décide, mais tout le monde doit alors utiliser le même.
