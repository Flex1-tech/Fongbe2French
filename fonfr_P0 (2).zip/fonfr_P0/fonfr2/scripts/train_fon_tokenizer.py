"""Crée le tokenizer FONGBÉ (SentencePiece Unigram), mêmes réglages que le tokenizer français de l'équipe :
Unigram, normalisation 'identity', couverture 1.0, indices spéciaux <pad>=0 <unk>=1 <s>=2 </s>=3.
Entraîné sur le TRAIN uniquement (jamais val ni test).
Usage : python scripts/train_fon_tokenizer.py [--vocab 2000]"""
import argparse, os
import pandas as pd, sentencepiece as spm
ap = argparse.ArgumentParser(); ap.add_argument("--vocab", type=int, default=2000)
ap.add_argument("--train", default="data/train.csv"); ap.add_argument("--out", default="tokenizers/fon")
a = ap.parse_args()
tmp = "data/_train_fon.txt"
open(tmp, "w", encoding="utf-8").write("\n".join(pd.read_csv(a.train).fon.astype(str)) + "\n")
spm.SentencePieceTrainer.train(input=tmp, model_prefix=a.out, vocab_size=a.vocab, model_type="unigram",
    character_coverage=1.0, pad_id=0, unk_id=1, bos_id=2, eos_id=3, normalization_rule_name="identity", minloglevel=2)
os.remove(tmp)
print("tokenizer fongbé créé :", a.out + ".model")
