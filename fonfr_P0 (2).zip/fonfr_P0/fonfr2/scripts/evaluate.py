"""Script d'évaluation COMMUN : mêmes options pour tout le monde.
Entrées : fichier d'hypothèses et de références (une phrase par ligne, texte DÉTOKENISÉ).
Usage   : python scripts/evaluate.py --hyp hyp.txt --ref ref.txt [--out res.json]
Comparaison appariée (bootstrap) avec P0 :
          python scripts/evaluate.py --hyp hyp_p1.txt --ref ref.txt --baseline hyp_p0.txt
"""
import argparse, json
from sacrebleu.metrics import BLEU, CHRF

BLEU_KW = dict(tokenize="13a", lowercase=True, smooth_method="exp")   # figés pour tout le groupe
CHRF_KW = dict(lowercase=True)                                       # chrF standard (char 6, word 0, beta 2)

def read(p):
    return [l.rstrip("\n") for l in open(p, encoding="utf-8")]

def score(hyps, refs):
    """Retourne {'bleu', 'chrf'} pour des listes de phrases détokenisées."""
    assert len(hyps) == len(refs), f"{len(hyps)} hypothèses pour {len(refs)} références"
    return {"bleu": round(BLEU(**BLEU_KW).corpus_score(hyps, [refs]).score, 2),
            "chrf": round(CHRF(**CHRF_KW).corpus_score(hyps, [refs]).score, 2),
            "n": len(refs)}

def paired(hyps, base, refs, n=1000, seed=42):
    """Bootstrap apparié : proportion de rééchantillons où hyps bat base (BLEU et chrF)."""
    import random
    rnd = random.Random(seed); idx = range(len(refs)); wins = {"bleu": 0, "chrf": 0}
    for _ in range(n):
        s = [rnd.choice(idx) for _ in idx]
        h, b, r = [hyps[i] for i in s], [base[i] for i in s], [refs[i] for i in s]
        sh, sb = score(h, r), score(b, r)
        for k in wins: wins[k] += sh[k] > sb[k]
    return {k: round(v / n, 3) for k, v in wins.items()}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--hyp", required=True); ap.add_argument("--ref", required=True)
    ap.add_argument("--baseline"); ap.add_argument("--out")
    a = ap.parse_args()
    hyp, ref = read(a.hyp), read(a.ref)
    res = score(hyp, ref)
    if a.baseline:
        base = read(a.baseline)
        res["baseline"] = score(base, ref)
        res["p_gagne_vs_baseline"] = paired(hyp, base, ref)
    print(json.dumps(res, indent=2))
    if a.out: json.dump(res, open(a.out, "w"), indent=2)
