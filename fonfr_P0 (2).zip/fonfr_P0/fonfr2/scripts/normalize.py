"""Normalisation commune (importée par la préparation, l'application web, etc.).
Même fonction partout : un prétraitement différent dégrade les traductions sans erreur."""
import re
import unicodedata

CARON, BREVE, GRAVE, ACUTE = "\u030c", "\u0306", "\u0300", "\u0301"

# Variantes d'orthographe fongbé (côté source uniquement)
FON_CHAR_MAP = {
    "ε": "ɛ",            # epsilon grec -> epsilon latin ouvert
    "Ε": "Ɛ",
    "ὲ": "ɛ" + GRAVE,    # epsilon grec + accent grave
    "έ": "ɛ" + ACUTE,    # epsilon grec + accent aigu
    "đ": "ɖ", "ð": "ɖ", "Đ": "Ɖ", "Ð": "Ɖ",   # d barré / eth -> ɖ
    "\u201a": ",",       # guillemet bas utilisé comme virgule
}
APOS = {"\u2019": "'", "\u2018": "'", "\u2032": "'", "\u00b4": "'", "`": "'"}

def _fix_breve_to_caron(s: str) -> str:
    # ă ŭ ĭ ĕ ŏ (brève) -> ǎ ǔ ǐ ě ǒ (caron) : ton montant
    s = unicodedata.normalize("NFD", s)
    s = s.replace(BREVE, CARON)
    return unicodedata.normalize("NFC", s)

def clean_fon(s: str) -> str:
    s = unicodedata.normalize("NFC", str(s))
    for a, b in FON_CHAR_MAP.items():
        s = s.replace(a, b)
    for a, b in APOS.items():
        s = s.replace(a, b)
    s = _fix_breve_to_caron(s)
    s = s.lower()
    return re.sub(r"\s+", " ", s).strip()

def clean_fr(s: str) -> str:
    s = unicodedata.normalize("NFC", str(s))
    for a, b in APOS.items():
        s = s.replace(a, b)
    s = s.lower()
    return re.sub(r"\s+", " ", s).strip()
